import{c as P,j as r}from"./index-Cyk6xeE8.js";import{t as q,O as A}from"./Tooltip-Dr1G90Al.js";const O=({onClick:R,iconClass:e,color:u,btnType:v,mr:d,btnRestClass:f,type:x,loading:c,disabled:g,styles:h,label:t,ttMessage:C,children:m,afterLabelContent:p,standalone:$,containerRestClass:a=""})=>{if(m)return m;const s={sm:"px-2 py-1 text-xs",md:"px-3 py-1.5 text-sm",lg:"px-4 py-2 text-base"},o={primary:"border-primary text-primary hover:bg-primary/5",secondary:"border-gray-500 text-gray-500 hover:bg-gray-50",danger:"border-red-500 text-red-500 hover:bg-red-50",success:"border-green-500 text-green-500 hover:bg-green-50",warning:"border-yellow-500 text-yellow-500 hover:bg-yellow-50",info:"border-cyan-500 text-cyan-500 hover:bg-cyan-50"},l=d?`mr-${d}`:"",y=s[v]||s.sm,b=o[u]||o.primary;return r.jsx("span",{className:`
        inline-flex items-center min-w-fit
        border border-primary bg-muted
        text-sm text-muted-foreground-1
        -ms-px
        overflow-hidden
        ${$?"rounded":`
        first:rounded-s
        first:rounded-se-none
        last:rounded-es-none
        last:rounded-e
        only:rounded
        `}
        ${a}
        `,children:r.jsxs("button",{className:`font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed relative hover:z-10 focus:z-10 ${y} ${b} ${l} ${f}`,type:x,onClick:R,disabled:c||g,style:h,"aria-label":C||t,children:[c?r.jsx("i",{className:"fa fa-spinner fa-spin mr-1.5"}):e&&r.jsx("i",{className:`fa fa-${e} ${t?"mr-1.5":""}`}),t&&r.jsx("span",{children:t}),p&&r.jsx("span",{className:"ml-1",children:p})]})})},U=R=>{const e=P.c(21),{onClick:u,iconClass:v,ttMessage:d,mr:f,btnRestClass:x,containerRestClass:c,color:g,loading:h,disabled:t,btnType:C,children:m,type:p,placement:$,styles:a,label:s,afterLabelContent:o,standalone:l}=R,y=u===void 0?D:u,b=v===void 0?"":v,n=d===void 0?"":d,N=f===void 0?0:f,_=x===void 0?"":x,z=c===void 0?"":c,k=g===void 0?"primary":g,S=h===void 0?!1:h,T=t===void 0?!1:t,B=C===void 0?"sm":C,E=m===void 0?null:m,I=p===void 0?"button":p,L=$===void 0?"top":$;let j,i;if(e[0]!==_||e[1]!==B||e[2]!==E||e[3]!==k||e[4]!==z||e[5]!==T||e[6]!==b||e[7]!==S||e[8]!==N||e[9]!==y||e[10]!==L||e[11]!==a||e[12]!==s||e[13]!==o||e[14]!==l||e[15]!==n||e[16]!==I){i=Symbol.for("react.early_return_sentinel");e:{const M={onClick:y,iconClass:b,color:k,btnType:B,mr:N,btnRestClass:_,containerRestClass:z,type:I,loading:S,disabled:T,styles:a===void 0?{}:a,label:s===void 0?"":s,ttMessage:n,children:E,afterLabelContent:o===void 0?null:o,standalone:l===void 0?!1:l};if(n){let w;e[19]!==n?(w=q(n),e[19]=n,e[20]=w):w=e[20],i=r.jsx(A,{placement:L,overlay:w,children:O(M)});break e}j=O(M)}e[0]=_,e[1]=B,e[2]=E,e[3]=k,e[4]=z,e[5]=T,e[6]=b,e[7]=S,e[8]=N,e[9]=y,e[10]=L,e[11]=a,e[12]=s,e[13]=o,e[14]=l,e[15]=n,e[16]=I,e[17]=j,e[18]=i}else j=e[17],i=e[18];return i!==Symbol.for("react.early_return_sentinel")?i:j};function D(){}export{U as I};
