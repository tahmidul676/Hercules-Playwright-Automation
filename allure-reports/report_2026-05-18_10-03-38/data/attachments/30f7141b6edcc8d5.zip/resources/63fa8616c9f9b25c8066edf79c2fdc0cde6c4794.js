import{g as r,b as p}from"./vendor-charts-BDaDALyO.js";var o=p();const e=r(o);export{e as P};
