const e="/assets/empty-D7EkG0Rh.png";export{e};
