const a="_dashboard_summary_column_18019_1",s={dashboard_summary_column:a};export{s as S};
